export const API_KEY={
  CLIENT_ID:
  "0f64ae4b5c3a474abb707c03172162af",
  CLIENT_SECRET:
  "19f2bcceb38b439c8f2605a65ba8422d",
};